#!/bin/sh
cd /home/roothoo/Dropbox/roothoo.github.io
git add .
git commit -m 's'
git push
